import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      nav: {
        home: 'Home',
        services: 'Services',
        portfolio: 'Portfolio',
        pricing: 'Pricing',
        testimonials: 'Testimonials',
        contact: 'Contact',
        login: 'Login',
        signup: 'Signup',
      },
      hero: {
        greeting: 'Hi, I\'m',
        name: 'Zakaria Dahbaoui',
        role: 'Designer & AI Developer',
        subtitle: 'Graphic Design • Photography • Web Design • Branding • Artificial Intelligence',
        intro: 'I create stunning visual experiences through graphic design, photography, social media design, and AI-powered web solutions. Let\'s bring your creative vision to life with cutting-edge technology and artistic excellence.',
        cta: 'Contact Me',
      },
      services: {
        title: 'My Services',
        subtitle: 'Creative solutions for your brand',
        contact: 'Contact',
        graphic_design: 'Graphic Design',
        graphic_design_desc: 'Professional logo design, branding and visual identity',
        web_design: 'Web Design',
        web_design_desc: 'Modern and responsive websites with stunning UI/UX',
        ai_development: 'AI Development',
        ai_development_desc: 'Custom AI solutions and machine learning applications',
        branding: 'Branding',
        branding_desc: 'Complete brand development and corporate identity',
      },
      pricing: {
        title: 'Choose Your Plan',
        subtitle: 'Affordable packages for every need',
        basic: 'Basic',
        standard: 'Standard',
        premium: 'Premium',
        recommended: 'Recommended',
        features: {
          '1': 'Logo Design',
          '2': 'Business Card',
          '3': 'Social Media Kit',
          '4': 'Brand Guidelines',
          '5': 'Unlimited Revisions',
          '6': 'Priority Support',
        },
        signup: 'Contact Me',
      },
      testimonials: {
        title: 'What Clients Say',
        subtitle: 'Trusted by businesses worldwide',
      },
      about: {
        title: 'About Me',
        description: 'With over 5 years of experience in design and development, I specialize in creating stunning visual experiences that drive results. My expertise spans graphic design, photography, web development, and AI solutions.',
        social: 'Follow me on social media',
      },
      portfolio: {
        title: 'My Portfolio',
        subtitle: 'Showcasing my best work',
        all: 'All',
        design: 'Design',
        photography: 'Photography',
        web: 'Web',
        ai: 'AI',
      },
      gallery: {
        title: 'Gallery Showcase',
        subtitle: 'Explore my creative journey through visual storytelling and design excellence',
        fullscreen: 'View Fullscreen',
        active: 'Active',
        image_info: 'Gallery Image',
        of: 'of',
      },
      contact: {
        title: 'Get In Touch',
        subtitle: 'Let\'s work together',
        name: 'Name',
        email: 'dahbaoui2010@gmail.com',
        message: 'Message',
        send: 'Send Message',
        success: 'Message sent successfully!',
        error: 'Please fill all fields correctly.',
      },
    },
  },
  ar: {
    translation: {
      nav: {
        home: 'الرئيسية',
        services: 'الخدمات',
        portfolio: 'أعمالي',
        pricing: 'الأسعار',
        testimonials: 'آراء العملاء',
        contact: 'اتصل بي',
        login: 'تسجيل الدخول',
        signup: 'إنشاء حساب',
      },
      hero: {
        greeting: 'مرحبًا، أنا',
        name: 'زكرياء ذهبوي',
        role: 'مصمم ومطور ذكاء اصطناعي',
        subtitle: 'تصميم جرافيك • تصوير فوتوغرافي • تصميم مواقع • براندينغ • الذكاء الاصطناعي',
        intro: 'أُبدع تجارب بصرية مذهلة من خلال تصميم الجرافيك، التصوير الفوتوغرافي، تصميم وسائل التواصل الاجتماعي، وحلول الويب المدعومة بالذكاء الاصطناعي. دعونا نحول رؤيتك الإبداعية إلى حقيقة باستخدام أحدث التقنيات والتميز الفني.',
        cta: 'تواصل معي',
      },
      services: {
        title: 'خدماتي',
        subtitle: 'حلول إبداعية لعلامتك التجارية',
        contact: 'تواصل',
        graphic_design: 'التصميم الجرافيكي',
        graphic_design_desc: 'تصميم احترافي للشعارات، وبناء العلامة التجارية والهوية البصرية',
        web_design: 'تصميم مواقع الويب',
        web_design_desc: 'مواقع ويب حديثة ومتجاوبة مع واجهة وتجربة مستخدم مذهلة',
        ai_development: 'تطوير الذكاء الاصطناعي',
        ai_development_desc: 'حلول ذكاء اصطناعي مخصصة وتطبيقات التعلم الآلي',
        branding: 'العلامة التجارية',
        branding_desc: 'تطوير شامل للعلامة التجارية والهوية المؤسسية',
      },
      pricing: {
        title: 'اختر خطتك',
        subtitle: 'باقات بأسعار معقولة لكل احتياج',
        basic: 'أساسي',
        standard: 'قياسي',
        premium: 'مميز',
        recommended: 'موصى به',
        features: {
          '1': 'تصميم شعار',
          '2': 'بطاقة عمل',
          '3': 'طقم وسائل التواصل',
          '4': 'إرشادات العلامة التجارية',
          '5': 'تعديلات غير محدودة',
          '6': 'دعم أولوي',
        },
        signup: 'تواصل معي',
      },
      testimonials: {
        title: 'ماذا يقول العملاء',
        subtitle: 'موثوق من قبل الشركات حول العالم',
      },
      about: {
        title: 'عني',
        description: 'مع أكثر من 5 سنوات من الخبرة في التصميم والتطوير، أتخصص في إنشاء تجارب بصرية مذهلة تؤدي إلى نتائج. خبرتي تشمل التصميم الجرافيكي، التصوير الفوتوغرافي، تطوير المواقع، وحلول الذكاء الاصطناعي.',
        social: 'تابعني على وسائل التواصل الاجتماعي',
      },
      portfolio: {
        title: 'أعمالي',
        subtitle: 'عرض أفضل أعمالي',
        all: 'الكل',
        design: 'تصميم',
        photography: 'تصوير',
        web: 'ويب',
        ai: 'ذكاء اصطناعي',
      },
      gallery: {
        title: 'معرض الأعمال',
        subtitle: 'استكشف رحلتي الإبداعية من خلال القصص البصرية والتميز في التصميم',
        fullscreen: 'عرض ملء الشاشة',
        active: 'نشط',
        image_info: 'صورة المعرض',
        of: 'من',
      },
      contact: {
        title: 'تواصل معي',
        subtitle: 'لنبدأ العمل معًا',
        name: 'الاسم',
        email: 'dahbaoui2010@gmail.com',
        message: 'الرسالة',
        send: 'إرسال الرسالة',
        success: 'تم إرسال الرسالة بنجاح!',
        error: 'يرجى ملء جميع الحقول بشكل صحيح.',
      },
    },
  },
  es: {
    translation: {
      nav: {
        home: 'Inicio',
        services: 'Servicios',
        portfolio: 'Portafolio',
        pricing: 'Precios',
        testimonials: 'Testimonios',
        contact: 'Contacto',
        login: 'Iniciar Sesión',
        signup: 'Registrarse',
      },
      hero: {
        greeting: 'Hola, soy',
        name: 'Zakaria Dahbaoui',
        role: 'Diseñador y Desarrollador de IA',
        subtitle: 'Diseño Gráfico • Fotografía • Diseño Web • Branding • Inteligencia Artificial',
        intro: 'Creo experiencias visuales impresionantes a través del diseño gráfico, fotografía, diseño de redes sociales y soluciones web impulsadas por IA. Convirtamos tu visión creativa en realidad con tecnología de vanguardia y excelencia artística.',
        cta: 'Contáctame',
      },
      services: {
        title: 'Mis Servicios',
        subtitle: 'Soluciones creativas para tu marca',
        contact: 'Contactar',
        graphic_design: 'Diseño Gráfico',
        graphic_design_desc: 'Diseño profesional de logotipos, branding e identidad visual',
        web_design: 'Diseño Web',
        web_design_desc: 'Sitios web modernos y responsivos con UI/UX impresionante',
        ai_development: 'Desarrollo de IA',
        ai_development_desc: 'Soluciones de IA personalizadas y aplicaciones de machine learning',
        branding: 'Branding',
        branding_desc: 'Desarrollo completo de marca e identidad corporativa',
      },
      pricing: {
        title: 'Elige Tu Plan',
        subtitle: 'Paquetes asequibles para cada necesidad',
        basic: 'Básico',
        standard: 'Estándar',
        premium: 'Premium',
        recommended: 'Recomendado',
        features: {
          '1': 'Diseño de Logo',
          '2': 'Tarjeta de Presentación',
          '3': 'Kit de Redes Sociales',
          '4': 'Guías de Marca',
          '5': 'Revisiones Ilimitadas',
          '6': 'Soporte Prioritario',
        },
        signup: 'Contáctame',
      },
      testimonials: {
        title: 'Lo que Dicen los Clientes',
        subtitle: 'Confiado por empresas worldwide',
      },
      about: {
        title: 'Sobre Mí',
        description: 'Con más de 5 años de experiencia en diseño y desarrollo, me especializo en crear experiencias visuales impresionantes que generan resultados. Mi experiencia abarca diseño gráfico, fotografía, desarrollo web y soluciones de IA.',
        social: 'Sígueme en redes sociales',
      },
      portfolio: {
        title: 'Mi Portafolio',
        subtitle: 'Mostrando mi mejor trabajo',
        all: 'Todo',
        design: 'Diseño',
        photography: 'Fotografía',
        web: 'Web',
        ai: 'IA',
      },
      gallery: {
        title: 'Galería de Exposición',
        subtitle: 'Explora mi viaje creativo a través del storytelling visual y la excelencia en diseño',
        fullscreen: 'Ver Pantalla Completa',
        active: 'Activo',
        image_info: 'Imagen de Galería',
        of: 'de',









      },
      contact: {
        title: 'Ponte en Contacto',
        subtitle: 'Trabajemos juntos',
        name: 'Nombre',
        email: 'dahbaoui2010@gmail.com',
        message: 'Mensaje',
        send: 'Enviar Mensaje',
        success: '¡Mensaje enviado exitosamente!',
        error: 'Por favor completa todos los campos correctamente.',
      },
    },
  },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: false,
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;