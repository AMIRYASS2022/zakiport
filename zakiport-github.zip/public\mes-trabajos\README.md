# Carpeta para imágenes de "mes trabajos"

Para usar tus propias imágenes en la galería 3D:

1. Copia tus imágenes aquí
2. Nómbralas como: trabajo1.jpg, trabajo2.jpg, etc.
3. Formatos soportados: JPG, PNG, WebP
4. Máximo 10 imágenes
5. Las imágenes se cargarán automáticamente

Si no hay imágenes aquí, la galería usará imágenes predeterminadas.